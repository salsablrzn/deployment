<footer><p>All right reserved. <a href="http://webthemez.com">@Salsa</a></p>  
        </footer>