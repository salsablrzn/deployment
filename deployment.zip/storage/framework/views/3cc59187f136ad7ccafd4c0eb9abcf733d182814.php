<!DOCTYPE html> 
<html> 
<head> 
    <title>Cetak  Barcode</title> 
    <style>
        @page  { margin-top:11.338582677px; margin-left:12.4488188976px;}
    </style>
</head> 
<body> 
    <table  width="100%"> 
    <tr> 
      <?php for($i = 0; $i< 40; $i++): ?>
       <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
       <td align="center"  style="border: 1px solid #ccc; width:147.96062992px; height:47.990551181; padding-bottom: 1.9692913386; padding-top: 2.6692913386;"> 
        <?php echo e($br->nama); ?><br>
       <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG(
       $br->id_barang, 'C128')); ?>" height="15" width="100">
      <br><?php echo e($br->id_barang); ?>

      </td>
      <?php if($no++ %5 ==0): ?>
           </tr><tr>
      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endfor; ?>
    </tr>
   </tsble>
  </body>
</html><?php /**PATH C:\xampp\htdocs\deployment\resources\views//barcode/barcodeId.blade.php ENDPATH**/ ?>