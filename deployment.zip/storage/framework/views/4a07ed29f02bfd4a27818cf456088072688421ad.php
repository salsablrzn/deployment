
<?php $__env->startSection('konten'); ?>

<div id="wrapper">
<div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Data Customer <br>
                            <small>Berikut Tabel Data Customer</small>
                        </h1>
            <ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li><a href="#">Customer</a></li>
  <li class="active">Tabel</li>
</ol>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
  
 <!-- page content -->
 <div class="right_col" role="main">
    <div class="">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_content">
              <table id="datatable-buttons" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>ID Customer</th>
                    <th>ID Kelurahan</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Foto</th>
                    <th>File Path</th>
                  </tr>
                </thead>

                <tbody>
                  <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($c->ID_CUSTOMER); ?></td>
                    <td><?php echo e($c->ID_KELURAHAN); ?></td>
                    <td><?php echo e($c->NAMA); ?></td>
                    <td><?php echo e($c->ALAMAT); ?></td>
                    <td><?php if( isset($c->FOTO) ): ?>
                      <img src="<?php echo e((base64_decode($c->FOTO))); ?>"><?php endif; ?></td>
                    <td><?php if( isset($c->FILE_PATH) ): ?>
                      <img src="<?php echo e(asset($c->FILE_PATH)); ?>"> <?php endif; ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
  <!-- /page content -->
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deployment\resources\views//customer/index.blade.php ENDPATH**/ ?>