<div id="sideNav" href=""><i class="fa fa-caret-right"></i></div>
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">                

                    <li>
                        <a href="#"><i class="fa fa-user"></i> Customer<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="customerindex">Data Customer</a>
                            </li>
                            <li>
                                <a href="customercreate">Tambah Customer 1</a>
                            </li>
                            <li>
                                <a href="customercreate2">Tambah Customer 2</a>
                            </li>                            
                            
                        </ul>
                    </li>

                    <li>
                        <a href="#"><i class="fa fa-shopping-cart"></i> Barang<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                            <!-- <li>
                                <a href="barcodebarang">Barang</a>
                            </li> -->
                            <li>
                                <a href="barcode">Barcode</a>
                            </li>
                            <li>
                                <a href="barcodescanner">Barcode Scanner</a>
                            </li>                              
                            
                        </ul>
                    </li>

                    <li>
                        <a href="#"><i class="fa fa-location-arrow"></i> GeoLocation<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                            <li>
                                <a href="location">Data Toko</a>
                            </li>
                            <li>
                                <a href="titikawal">Input Titik Awal</a>
                            </li>    
                            <li>
                                <a href="titikkunjungan">Input Titik Kunjungan</a>
                            </li>                              
                            
                        </ul>
                    </li>

                </ul>                

            </div>

            <?php /**PATH C:\xampp\htdocs\deployment\resources\views/tampilan/sidebar.blade.php ENDPATH**/ ?>