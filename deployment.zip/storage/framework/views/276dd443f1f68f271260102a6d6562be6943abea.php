<!DOCTYPE html> 
<html> 
<head> 
    <title>Cetak  Barcode</title> 
    <style>
        @page  { margin-top:11.338582677px; margin-left:12.4488188976px;}
    </style>
</head> 
<body> 
    <table  width="100%"> 
    <tr> 
    <?php for($i = 0; $i < 40; $i++): ?> 
       <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
       <td align="center"  style="border: 1px solid #ccc; width:146.96062992px; height:47.990551181; padding-bottom: 2.1692913386; padding-top: 2.6692913386; padding-left: 3;"> 
       <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG(
       $lok->barcode, 'C128')); ?>" height="15" width="100">
      <br><?php echo e($lok->barcode); ?><br><?php echo e($lok->nama_toko); ?>

      </td>
      <?php if($no++ %5 ==0): ?>
           </tr><tr>
      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endfor; ?>
    </tr>
   </tsble>
  </body>
</html><?php /**PATH C:\xampp\htdocs\deployment\resources\views/location/cetakBarcodeId.blade.php ENDPATH**/ ?>