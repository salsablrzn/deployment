
<?php $__env->startSection('konten'); ?>

<div class="content ">
                
<div id="wrapper">
<div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Data Toko <br>
                            <small>Berikut merupakan tabel data toko</small>
                        </h1>
            <ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li><a href="#">GeoLocation</a></li>
  <li class="active">Data Toko</li>
</ol>
                    </div>
                </div>
            </div>


    <div class="row">
<div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <!-- <div class="panel-heading">
                             Data Customer
                        </div> -->
                        <div class="panel-body">
                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap">
                                  <thead>
								  <th class="text-center">Barcode</th>
								  <th class="text-center">Nama toko</th>                                   
								  <th class="text-center">Latitude</th>                        
								  <th class="text-center">Longtitude</th>
								  <th class="text-center">Accuracy</th>
                                  <th class="text-center">Action</th>
							  </thead>
                                <tbody>
                                	<?php $__currentLoopData = $lokasi_toko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  <tr align="center">
										  <td> <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG(
							                    $lok->barcode, 'C128')); ?>" height="60" width="180">
							                    <br><?php echo e($lok->barcode); ?></td>
										  <td><?php echo e($lok->nama_toko); ?></td>
										  <td><?php echo e($lok->latitude); ?></td>
										  <td><?php echo e($lok->longitude); ?></td>
										  <td><?php echo e($lok->accuracy); ?></td>
                                           <td><a href="/cetakBarcodeLokasiId/<?php echo e($lok->barcode); ?>"><button class="btn btn-success">Cetak Barcode</button</a></td>
									  </tr> 
									  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
                            </table>

                            <center>
        <a href="cetakbarcodelokasiii"><button type="button" class="btn btn-primary">Cetak All 1 Barcode</button>                           
        <a href="cetakbarcodelokasi"><button type="button" class="btn btn-primary">Cetak All 40 Barcode</button>
        
         </center>

                            </div>
                            
                        </div>
                        </div>
                        
         
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deployment\resources\views/location/location.blade.php ENDPATH**/ ?>