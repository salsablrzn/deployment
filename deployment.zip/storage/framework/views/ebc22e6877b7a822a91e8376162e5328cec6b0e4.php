<footer><p>All right reserved. <a href="http://webthemez.com">@Salsa</a></p>  
        </footer><?php /**PATH C:\xampp\htdocs\deployment\resources\views/tampilan/footer.blade.php ENDPATH**/ ?>